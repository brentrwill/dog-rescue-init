package com.promineotech.dogrescue.controller.error;

public class DuplicateKeyException extends Exception {
	private static final long serialVersionUID = 1L;
}
