package com.promineotech.dogrescue.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.HashSet;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.SqlConfig;

import com.promineotech.dogrescue.DogRescueApplication;
import com.promineotech.dogrescue.controller.model.LocationData;
import com.promineotech.dogrescue.entity.Dog;

@SpringBootTest(webEnvironment = WebEnvironment.NONE, classes = DogRescueApplication.class)
@ActiveProfiles("test")
@SqlConfig(encoding = "utf-8")
public class LocationControllerTest extends RescueServiceTestSupport {

	// @Test
	@SuppressWarnings(value = { "test" })
	public void testInsertLocation() {
		LocationData request = buildLocation(1);
		LocationData expected = buildLocation(1);
		expected.setLocationId(1);
		expected.setDogs(new HashSet<Dog>());

		ResponseEntity<LocationData> response = insertLocation(request);
		LocationData actual = response.getBody();
		HttpStatusCode status = response.getStatusCode();
		int statusCode = status.value();
		boolean results = actual.equals(expected);

		assertEquals(true, results);
		assertEquals(statusCode, 200);
	}

	// @Test
	public void testGetLocation() {
		LocationData request = buildLocation(10);
		ResponseEntity<LocationData> response = insertLocation(request);
		LocationData location = response.getBody();

		response = getLocation(location.getLocationId());
		LocationData actual = response.getBody();
		HttpStatusCode status = response.getStatusCode();
		int statusCode = status.value();
		boolean results = actual.equals(location);

		assertEquals(true, results);
		assertEquals(statusCode, 200);
	}

	// @Test
	public void testGetAllLocations() {
		LocationData loc1 = buildLocation(1);
		LocationData loc2 = buildLocation(2);
		insertLocation(loc1);
		insertLocation(loc2);

		ResponseEntity<List<LocationData>> data = getAllLocations();
		List<LocationData> locations = data.getBody();
		HttpStatusCode status = data.getStatusCode();
		int statusCode = status.value();

		assertEquals(locations.size(), 4);
		assertEquals(statusCode, 200);
	}

	@Test
	public void testDeleteLocation() {
		LocationData request = buildLocation(1);

		ResponseEntity<LocationData> response = insertLocation(request);
		LocationData actual = response.getBody();
		HttpStatusCode status = response.getStatusCode();
		int statusCode = status.value();
		assertEquals(statusCode, 200);

		Long locationId = actual.getLocationId();
		deleteLocation(locationId);

		assertThrows(NoSuchElementException.class, () -> {
			ResponseEntity<LocationData> resp = getLocation(locationId);
		});
	}
}
